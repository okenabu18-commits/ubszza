ABU DEVS PORTFOLIO WEBSITE

1. Extract this ZIP folder.
2. Open index.html in Chrome to preview.
3. Upload the complete abu_devs_pro folder to Netlify, Vercel, or any static web host.

All artwork is stored locally in assets/. Keep the assets folder beside index.html.
Discord: https://discord.gg/BZkGrYTuK
Telegram: https://t.me/ABU_DEVS

The game showcase cards are example concepts. Replace them with your real Roblox game links when available.

V2 UPDATE: Profile artwork now uses the supplied Napoleon image. Header brand and browser favicon use a custom ABU DEVS crown/A emblem; no ChatGPT swirl icon is used.
